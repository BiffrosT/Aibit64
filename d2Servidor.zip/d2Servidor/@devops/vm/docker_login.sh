#!/usr/bin/env bash

export DOCKER_USERNAME=user
export DOCKER_PASSWORD=password

docker login --username=$DOCKER_USERNAME --password=$DOCKER_PASSWORD