#!/usr/bin/env bash

./scripts/server/build.sh
docker push eubrunomiguel/tibia
