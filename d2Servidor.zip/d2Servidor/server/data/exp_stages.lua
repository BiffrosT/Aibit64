stages = {
	{minLevel = 1, maxLevel = 30, multiplier= 13},
	{minLevel = 31, maxLevel = 50, multiplier= 8},
	{minLevel = 51, maxLevel = 70, multiplier = 6},
	{minLevel = 71, maxLevel = 90, multiplier = 3},
	{minLevel = 91, maxLevel = 666, multiplier = 2}
}
