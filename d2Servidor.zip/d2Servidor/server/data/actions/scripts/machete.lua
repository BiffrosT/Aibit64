function onUse(cid, item, frompos, item2, topos)
	return useMachete(cid, item, frompos, item2, topos)
end
