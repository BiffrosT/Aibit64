

function onUse(cid, item, frompos, item2, topos)

	doTransformItem(item.uid,item.itemid-2)
	return 1

end