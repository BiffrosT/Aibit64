function onUse(cid, item, frompos, item2, topos)
	return useScythe(cid, item, frompos, item2, topos)
end
