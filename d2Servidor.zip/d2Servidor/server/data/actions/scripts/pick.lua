function onUse(cid, item, fromPosition, itemEx, toPosition)
	return usePick(cid, item, fromPosition, itemEx, toPosition)
end

