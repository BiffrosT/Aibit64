function onUse(cid, item, frompos, item2, topos)
	return useShovel(cid, item, frompos, item2, topos)
end
