function onUse(cid, item, frompos, item2, topos)
	doSendMagicEffect(frompos, 18)	
	return 1
end