function onUse(cid, item, frompos, item2, topos)
	return useRope(cid, item, frompos, item2, topos)
end
